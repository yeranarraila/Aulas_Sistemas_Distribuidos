import br.ufsc.das.tom.TOMSender;
import br.ufsc.das.util.CommunicationSystem;
import br.ufsc.das.util.TOMConfiguration;

public class Cliente extends TOMSender {

    private CommunicationSystem cs;

    /** Creates a new instance of Cliente */
    public Cliente() {
        int id = Math.abs((int) System.currentTimeMillis());
        //cria objeto de configuracao
        TOMConfiguration conf = new TOMConfiguration(id);
        //cria comunicacao com o sistema
        cs = new CommunicationSystem(conf);
        //inicializa o comunicador
        this.init(cs, conf);
    }


    public void TOMReplyReceive(Object reply){ //recebe a resposta do servidor

        System.out.println("Resposta recebida: "+reply.toString()+"\n");
    }

    private void run(){

        //Aqui virao as acoes do Cliente
        String msg = "Hello World";
        int arg1=1;
        int arg2=2;
        Object[] obj = new Object[3];
        obj[0] = msg;
        obj[1] = arg1;
        obj[2] = arg2;

        System.out.println("\nEnviando Requisicao...\n");
        this.TOMulticast(obj); //envia a requisicao(obj)
        System.out.println("\nRequisicao enviada!\n");
    }

    public static void main(String[] args){
        new Cliente().run();
    }

}
