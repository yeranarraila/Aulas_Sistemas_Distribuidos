import br.ufsc.das.tom.TOMReceiver;
import br.ufsc.das.tom.util.TOMMessage;
import br.ufsc.das.util.CommunicationSystem;
import br.ufsc.das.util.TOMConfiguration;

public class Servidor extends TOMReceiver{

    private CommunicationSystem cs;
    private int id;

    /** Cria uma instancia do Servidor */
    public Servidor(int id) {
        this.id = id;
    }

    private void run(){
        //Criando o objeto de configuracao
        TOMConfiguration conf = new TOMConfiguration(id);
        //ciando o sistema de comunicacao
        cs = new CommunicationSystem(conf);
        //registrando-se no sistema distribuido
        this.init(cs,conf);
    }


    public void TOMRequestReceive(TOMMessage msg){
        System.out.println("\nProcessando requisicao recebida...\n");
        //msg.getContent() pega o conteudo da mensagem passada para o servidor.
        // Acoes do servidor
        String result = "Hello World from Distributed System, machine "+this.id;
        //retira do espaco
        Object[] obj = (Object[])msg.getContent();

      	System.out.println("Recebi do cliente o seguinte: "+obj[0].toString()+"\n"+Integer.parseInt(obj[1].toString())+"\n"+Integer.parseInt(obj[2].toString()));

        System.out.println("\nEnviando Resposta: "+result+" .\n");
        //TOMMessage (id_de_quem_envia,id_da_sequencia(semaforo),conteudo_tipo_Object,tipo_da_mensagem);
        TOMMessage reply = new TOMMessage(id,msg.getSequence(),(Object)result,CommunicationSystem.TOM_REPLY_MSG);
        cs.send(new int[]{msg.getSender()},reply); //responde ao cliente (id_do_cliente,TOMMessage);
        System.out.println("\nResposta enviada.\n");
    }


    public static void main(String[] args){
        int id = -1;
        try{
            id = Integer.parseInt(args[0]);
        }catch(Exception e){
            System.out.println("Use: java Servidor <processId>");
            System.exit(0);
        }
        new Servidor(id).run();
    }


}
